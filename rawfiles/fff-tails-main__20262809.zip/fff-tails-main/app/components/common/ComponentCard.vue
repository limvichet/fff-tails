<template>
  <div
    :class="[
      'rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]',
      className,
    ]"
  >
    <!-- Card Header -->
    <div class="px-6 py-2">
      <h3 class="">
        <span class="text-base font-medium text-blue-900 dark:text-white/90">{{ title }}</span> 
      </h3>
      <p v-if="desc" class="mt-1 text-sm text-gray-500 dark:text-gray-400">
        {{ desc }}
      </p>
    </div>

    <!-- Card Body -->
    <div class="p-2 border-t border-gray-100 dark:border-gray-800 sm:p-6">
      <div class="space-y-5">
        <slot></slot>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">

interface Props {
  title: string
  className?: string
  desc?: string
}

defineProps<Props>()
</script>
