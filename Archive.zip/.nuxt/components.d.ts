
import type { DefineComponent, SlotsType } from 'vue'
type IslandComponent<T> = DefineComponent<{}, {refresh: () => Promise<void>}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, SlotsType<{ fallback: { error: unknown } }>> & T

type HydrationStrategies = {
  hydrateOnVisible?: IntersectionObserverInit | true
  hydrateOnIdle?: number | true
  hydrateOnInteraction?: keyof HTMLElementEventMap | Array<keyof HTMLElementEventMap> | true
  hydrateOnMediaQuery?: string
  hydrateAfter?: number
  hydrateWhen?: boolean
  hydrateNever?: true
}
type LazyComponent<T> = DefineComponent<HydrationStrategies, {}, {}, {}, {}, {}, {}, { hydrated: () => void }> & T


export const ShowAuthError: typeof import("../app/components/ShowAuthError.vue").default
export const CommonGridShape: typeof import("../app/components/common/CommonGridShape.vue").default
export const CommonComponentCard: typeof import("../app/components/common/ComponentCard.vue").default
export const CommonComponentSubmitCard: typeof import("../app/components/common/ComponentSubmitCard.vue").default
export const CommonPageBreadcrumb: typeof import("../app/components/common/PageBreadcrumb.vue").default
export const CommonThemeToggler: typeof import("../app/components/common/ThemeToggler.vue").default
export const FormsFormElementsCheckboxInput: typeof import("../app/components/forms/FormElements/CheckboxInput.vue").default
export const FormsFormElementsDefaultInputs: typeof import("../app/components/forms/FormElements/DefaultInputs.vue").default
export const FormsFormElementsDropzone: typeof import("../app/components/forms/FormElements/Dropzone.vue").default
export const FormsFormElementsDropzoneImage copy: typeof import("../app/components/forms/FormElements/DropzoneImage copy.vue").default
export const FormsFormElementsDropzoneImage: typeof import("../app/components/forms/FormElements/DropzoneImage.vue").default
export const FormsFormElementsFileInput: typeof import("../app/components/forms/FormElements/FileInput.vue").default
export const FormsFormElementsInputGroup: typeof import("../app/components/forms/FormElements/InputGroup.vue").default
export const FormsFormElementsInputState: typeof import("../app/components/forms/FormElements/InputState.vue").default
export const FormsFormElementsSelectInput: typeof import("../app/components/forms/FormElements/SelectInput.vue").default
export const FormsFormElementsTextArea: typeof import("../app/components/forms/FormElements/TextArea.vue").default
export const LayoutAdminLayout: typeof import("../app/components/layout/AdminLayout.vue").default
export const LayoutAppHeader: typeof import("../app/components/layout/AppHeader.vue").default
export const LayoutAppSidebar: typeof import("../app/components/layout/AppSidebar.vue").default
export const LayoutBackdrop: typeof import("../app/components/layout/Backdrop.vue").default
export const LayoutFullScreenLayout: typeof import("../app/components/layout/FullScreenLayout.vue").default
export const LayoutSidebarProvider: typeof import("../app/components/layout/SidebarProvider.vue").default
export const LayoutSidebarWidget: typeof import("../app/components/layout/SidebarWidget.vue").default
export const LayoutThemeProvider: typeof import("../app/components/layout/ThemeProvider.vue").default
export const LayoutHeaderLogo: typeof import("../app/components/layout/header/HeaderLogo.vue").default
export const LayoutHeaderNotificationMenu copy: typeof import("../app/components/layout/header/NotificationMenu copy.vue").default
export const LayoutHeaderNotificationMenu: typeof import("../app/components/layout/header/NotificationMenu.vue").default
export const LayoutHeaderSearchBar: typeof import("../app/components/layout/header/SearchBar.vue").default
export const LayoutHeaderUserMenu: typeof import("../app/components/layout/header/UserMenu.vue").default
export const NuxtWelcome: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/welcome.vue").default
export const NuxtLayout: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-layout").default
export const NuxtErrorBoundary: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue").default
export const ClientOnly: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/client-only").default
export const DevOnly: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/dev-only").default
export const ServerPlaceholder: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/server-placeholder").default
export const NuxtLink: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-link").default
export const NuxtLoadingIndicator: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-loading-indicator").default
export const NuxtTime: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-time.vue").default
export const NuxtRouteAnnouncer: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-route-announcer").default
export const NuxtImg: typeof import("../node_modules/.pnpm/@nuxt+image@2.0.0_db0@0.3.4_ioredis@5.9.2_magicast@0.5.1/node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue").default
export const NuxtPicture: typeof import("../node_modules/.pnpm/@nuxt+image@2.0.0_db0@0.3.4_ioredis@5.9.2_magicast@0.5.1/node_modules/@nuxt/image/dist/runtime/components/NuxtPicture.vue").default
export const Icon: typeof import("../node_modules/.pnpm/@nuxt+icon@2.2.0_magicast@0.5.1_vite@7.3.1_@types+node@25.0.9_jiti@2.6.1_lightningcss@1_6da89c9b593b6e4c25ec361b88ecb6f2/node_modules/@nuxt/icon/dist/runtime/components/index").default
export const ColorScheme: typeof import("../node_modules/.pnpm/@nuxtjs+color-mode@4.0.0_magicast@0.5.1/node_modules/@nuxtjs/color-mode/dist/runtime/component.vue").default
export const OgImage: typeof import("../node_modules/.pnpm/nuxt-og-image@5.1.13_@unhead+vue@2.1.2_vue@3.5.27_typescript@5.9.3___magicast@0.5.1_uns_8d5afb97e113681a3783549c3b584ba2/node_modules/nuxt-og-image/dist/runtime/app/components/OgImage/OgImage").default
export const OgImageScreenshot: typeof import("../node_modules/.pnpm/nuxt-og-image@5.1.13_@unhead+vue@2.1.2_vue@3.5.27_typescript@5.9.3___magicast@0.5.1_uns_8d5afb97e113681a3783549c3b584ba2/node_modules/nuxt-og-image/dist/runtime/app/components/OgImage/OgImageScreenshot").default
export const NuxtPage: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/pages/runtime/page").default
export const NoScript: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").NoScript
export const Link: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Link
export const Base: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Base
export const Title: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Title
export const Meta: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Meta
export const Style: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Style
export const Head: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Head
export const Html: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Html
export const Body: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Body
export const NuxtIsland: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-island").default
export const LazyShowAuthError: LazyComponent<typeof import("../app/components/ShowAuthError.vue").default>
export const LazyCommonGridShape: LazyComponent<typeof import("../app/components/common/CommonGridShape.vue").default>
export const LazyCommonComponentCard: LazyComponent<typeof import("../app/components/common/ComponentCard.vue").default>
export const LazyCommonComponentSubmitCard: LazyComponent<typeof import("../app/components/common/ComponentSubmitCard.vue").default>
export const LazyCommonPageBreadcrumb: LazyComponent<typeof import("../app/components/common/PageBreadcrumb.vue").default>
export const LazyCommonThemeToggler: LazyComponent<typeof import("../app/components/common/ThemeToggler.vue").default>
export const LazyFormsFormElementsCheckboxInput: LazyComponent<typeof import("../app/components/forms/FormElements/CheckboxInput.vue").default>
export const LazyFormsFormElementsDefaultInputs: LazyComponent<typeof import("../app/components/forms/FormElements/DefaultInputs.vue").default>
export const LazyFormsFormElementsDropzone: LazyComponent<typeof import("../app/components/forms/FormElements/Dropzone.vue").default>
export const LazyFormsFormElementsDropzoneImage copy: LazyComponent<typeof import("../app/components/forms/FormElements/DropzoneImage copy.vue").default>
export const LazyFormsFormElementsDropzoneImage: LazyComponent<typeof import("../app/components/forms/FormElements/DropzoneImage.vue").default>
export const LazyFormsFormElementsFileInput: LazyComponent<typeof import("../app/components/forms/FormElements/FileInput.vue").default>
export const LazyFormsFormElementsInputGroup: LazyComponent<typeof import("../app/components/forms/FormElements/InputGroup.vue").default>
export const LazyFormsFormElementsInputState: LazyComponent<typeof import("../app/components/forms/FormElements/InputState.vue").default>
export const LazyFormsFormElementsSelectInput: LazyComponent<typeof import("../app/components/forms/FormElements/SelectInput.vue").default>
export const LazyFormsFormElementsTextArea: LazyComponent<typeof import("../app/components/forms/FormElements/TextArea.vue").default>
export const LazyLayoutAdminLayout: LazyComponent<typeof import("../app/components/layout/AdminLayout.vue").default>
export const LazyLayoutAppHeader: LazyComponent<typeof import("../app/components/layout/AppHeader.vue").default>
export const LazyLayoutAppSidebar: LazyComponent<typeof import("../app/components/layout/AppSidebar.vue").default>
export const LazyLayoutBackdrop: LazyComponent<typeof import("../app/components/layout/Backdrop.vue").default>
export const LazyLayoutFullScreenLayout: LazyComponent<typeof import("../app/components/layout/FullScreenLayout.vue").default>
export const LazyLayoutSidebarProvider: LazyComponent<typeof import("../app/components/layout/SidebarProvider.vue").default>
export const LazyLayoutSidebarWidget: LazyComponent<typeof import("../app/components/layout/SidebarWidget.vue").default>
export const LazyLayoutThemeProvider: LazyComponent<typeof import("../app/components/layout/ThemeProvider.vue").default>
export const LazyLayoutHeaderLogo: LazyComponent<typeof import("../app/components/layout/header/HeaderLogo.vue").default>
export const LazyLayoutHeaderNotificationMenu copy: LazyComponent<typeof import("../app/components/layout/header/NotificationMenu copy.vue").default>
export const LazyLayoutHeaderNotificationMenu: LazyComponent<typeof import("../app/components/layout/header/NotificationMenu.vue").default>
export const LazyLayoutHeaderSearchBar: LazyComponent<typeof import("../app/components/layout/header/SearchBar.vue").default>
export const LazyLayoutHeaderUserMenu: LazyComponent<typeof import("../app/components/layout/header/UserMenu.vue").default>
export const LazyNuxtWelcome: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/welcome.vue").default>
export const LazyNuxtLayout: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-layout").default>
export const LazyNuxtErrorBoundary: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue").default>
export const LazyClientOnly: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/client-only").default>
export const LazyDevOnly: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/dev-only").default>
export const LazyServerPlaceholder: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/server-placeholder").default>
export const LazyNuxtLink: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-link").default>
export const LazyNuxtLoadingIndicator: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-loading-indicator").default>
export const LazyNuxtTime: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-time.vue").default>
export const LazyNuxtRouteAnnouncer: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-route-announcer").default>
export const LazyNuxtImg: LazyComponent<typeof import("../node_modules/.pnpm/@nuxt+image@2.0.0_db0@0.3.4_ioredis@5.9.2_magicast@0.5.1/node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue").default>
export const LazyNuxtPicture: LazyComponent<typeof import("../node_modules/.pnpm/@nuxt+image@2.0.0_db0@0.3.4_ioredis@5.9.2_magicast@0.5.1/node_modules/@nuxt/image/dist/runtime/components/NuxtPicture.vue").default>
export const LazyIcon: LazyComponent<typeof import("../node_modules/.pnpm/@nuxt+icon@2.2.0_magicast@0.5.1_vite@7.3.1_@types+node@25.0.9_jiti@2.6.1_lightningcss@1_6da89c9b593b6e4c25ec361b88ecb6f2/node_modules/@nuxt/icon/dist/runtime/components/index").default>
export const LazyColorScheme: LazyComponent<typeof import("../node_modules/.pnpm/@nuxtjs+color-mode@4.0.0_magicast@0.5.1/node_modules/@nuxtjs/color-mode/dist/runtime/component.vue").default>
export const LazyOgImage: LazyComponent<typeof import("../node_modules/.pnpm/nuxt-og-image@5.1.13_@unhead+vue@2.1.2_vue@3.5.27_typescript@5.9.3___magicast@0.5.1_uns_8d5afb97e113681a3783549c3b584ba2/node_modules/nuxt-og-image/dist/runtime/app/components/OgImage/OgImage").default>
export const LazyOgImageScreenshot: LazyComponent<typeof import("../node_modules/.pnpm/nuxt-og-image@5.1.13_@unhead+vue@2.1.2_vue@3.5.27_typescript@5.9.3___magicast@0.5.1_uns_8d5afb97e113681a3783549c3b584ba2/node_modules/nuxt-og-image/dist/runtime/app/components/OgImage/OgImageScreenshot").default>
export const LazyNuxtPage: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/pages/runtime/page").default>
export const LazyNoScript: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").NoScript>
export const LazyLink: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Link>
export const LazyBase: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Base>
export const LazyTitle: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Title>
export const LazyMeta: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Meta>
export const LazyStyle: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Style>
export const LazyHead: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Head>
export const LazyHtml: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Html>
export const LazyBody: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Body>
export const LazyNuxtIsland: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-island").default>

export const componentNames: string[]
