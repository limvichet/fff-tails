/// <reference types="@nuxt/icon" />
/// <reference types="@nuxt/fonts" />
/// <reference types="@nuxtjs/color-mode" />
/// <reference types="@nuxt/telemetry" />
/// <reference types="nuxt-og-image" />
/// <reference types="@nuxt/image" />
/// <reference types="@nuxt/devtools" />
/// <reference path="types/modules.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/app.config.d.ts" />
/// <reference types="nuxt" />
/// <reference types="../node_modules/.pnpm/@nuxt+vite-builder@4.2.2_@types+node@25.0.9_eslint@9.39.2_jiti@2.6.1__lightningcss@1.30_49cd28ac09401c2756d4f93e1ec0c6cf/node_modules/@nuxt/vite-builder/dist/index.mjs" />
/// <reference types="/Users/limvichet/Documents/Apps/fff-tails/node_modules/.pnpm/@nuxt+nitro-server@4.2.2_db0@0.3.4_ioredis@5.9.2_magicast@0.5.1_nuxt@4.2.2_@parcel+watc_e8da299e7b55e635d211545f0ba07074/node_modules/@nuxt/nitro-server/dist/index.mjs" />
/// <reference path="image/providers.d.ts" />
/// <reference path="types/nitro-middleware.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}
