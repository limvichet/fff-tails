
import type { DefineComponent, SlotsType } from 'vue'
type IslandComponent<T> = DefineComponent<{}, {refresh: () => Promise<void>}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, SlotsType<{ fallback: { error: unknown } }>> & T

type HydrationStrategies = {
  hydrateOnVisible?: IntersectionObserverInit | true
  hydrateOnIdle?: number | true
  hydrateOnInteraction?: keyof HTMLElementEventMap | Array<keyof HTMLElementEventMap> | true
  hydrateOnMediaQuery?: string
  hydrateAfter?: number
  hydrateWhen?: boolean
  hydrateNever?: true
}
type LazyComponent<T> = DefineComponent<HydrationStrategies, {}, {}, {}, {}, {}, {}, { hydrated: () => void }> & T

interface _GlobalComponents {
  'ShowAuthError': typeof import("../../app/components/ShowAuthError.vue").default
  'CommonGridShape': typeof import("../../app/components/common/CommonGridShape.vue").default
  'CommonComponentCard': typeof import("../../app/components/common/ComponentCard.vue").default
  'CommonComponentSubmitCard': typeof import("../../app/components/common/ComponentSubmitCard.vue").default
  'CommonPageBreadcrumb': typeof import("../../app/components/common/PageBreadcrumb.vue").default
  'CommonThemeToggler': typeof import("../../app/components/common/ThemeToggler.vue").default
  'FormsFormElementsCheckboxInput': typeof import("../../app/components/forms/FormElements/CheckboxInput.vue").default
  'FormsFormElementsDefaultInputs': typeof import("../../app/components/forms/FormElements/DefaultInputs.vue").default
  'FormsFormElementsDropzone': typeof import("../../app/components/forms/FormElements/Dropzone.vue").default
  'FormsFormElementsDropzoneImage copy': typeof import("../../app/components/forms/FormElements/DropzoneImage copy.vue").default
  'FormsFormElementsDropzoneImage': typeof import("../../app/components/forms/FormElements/DropzoneImage.vue").default
  'FormsFormElementsFileInput': typeof import("../../app/components/forms/FormElements/FileInput.vue").default
  'FormsFormElementsInputGroup': typeof import("../../app/components/forms/FormElements/InputGroup.vue").default
  'FormsFormElementsInputState': typeof import("../../app/components/forms/FormElements/InputState.vue").default
  'FormsFormElementsSelectInput': typeof import("../../app/components/forms/FormElements/SelectInput.vue").default
  'FormsFormElementsTextArea': typeof import("../../app/components/forms/FormElements/TextArea.vue").default
  'LayoutAdminLayout': typeof import("../../app/components/layout/AdminLayout.vue").default
  'LayoutAppHeader': typeof import("../../app/components/layout/AppHeader.vue").default
  'LayoutAppSidebar': typeof import("../../app/components/layout/AppSidebar.vue").default
  'LayoutBackdrop': typeof import("../../app/components/layout/Backdrop.vue").default
  'LayoutFullScreenLayout': typeof import("../../app/components/layout/FullScreenLayout.vue").default
  'LayoutSidebarProvider': typeof import("../../app/components/layout/SidebarProvider.vue").default
  'LayoutSidebarWidget': typeof import("../../app/components/layout/SidebarWidget.vue").default
  'LayoutThemeProvider': typeof import("../../app/components/layout/ThemeProvider.vue").default
  'LayoutHeaderLogo': typeof import("../../app/components/layout/header/HeaderLogo.vue").default
  'LayoutHeaderNotificationMenu copy': typeof import("../../app/components/layout/header/NotificationMenu copy.vue").default
  'LayoutHeaderNotificationMenu': typeof import("../../app/components/layout/header/NotificationMenu.vue").default
  'LayoutHeaderSearchBar': typeof import("../../app/components/layout/header/SearchBar.vue").default
  'LayoutHeaderUserMenu': typeof import("../../app/components/layout/header/UserMenu.vue").default
  'NuxtWelcome': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/welcome.vue").default
  'NuxtLayout': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-layout").default
  'NuxtErrorBoundary': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue").default
  'ClientOnly': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/client-only").default
  'DevOnly': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/dev-only").default
  'ServerPlaceholder': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/server-placeholder").default
  'NuxtLink': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-link").default
  'NuxtLoadingIndicator': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-loading-indicator").default
  'NuxtTime': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-time.vue").default
  'NuxtRouteAnnouncer': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-route-announcer").default
  'NuxtImg': typeof import("../../node_modules/.pnpm/@nuxt+image@2.0.0_db0@0.3.4_ioredis@5.9.2_magicast@0.5.1/node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue").default
  'NuxtPicture': typeof import("../../node_modules/.pnpm/@nuxt+image@2.0.0_db0@0.3.4_ioredis@5.9.2_magicast@0.5.1/node_modules/@nuxt/image/dist/runtime/components/NuxtPicture.vue").default
  'Icon': typeof import("../../node_modules/.pnpm/@nuxt+icon@2.2.0_magicast@0.5.1_vite@7.3.1_@types+node@25.0.9_jiti@2.6.1_lightningcss@1_6da89c9b593b6e4c25ec361b88ecb6f2/node_modules/@nuxt/icon/dist/runtime/components/index").default
  'ColorScheme': typeof import("../../node_modules/.pnpm/@nuxtjs+color-mode@4.0.0_magicast@0.5.1/node_modules/@nuxtjs/color-mode/dist/runtime/component.vue").default
  'OgImage': typeof import("../../node_modules/.pnpm/nuxt-og-image@5.1.13_@unhead+vue@2.1.2_vue@3.5.27_typescript@5.9.3___magicast@0.5.1_uns_8d5afb97e113681a3783549c3b584ba2/node_modules/nuxt-og-image/dist/runtime/app/components/OgImage/OgImage").default
  'OgImageScreenshot': typeof import("../../node_modules/.pnpm/nuxt-og-image@5.1.13_@unhead+vue@2.1.2_vue@3.5.27_typescript@5.9.3___magicast@0.5.1_uns_8d5afb97e113681a3783549c3b584ba2/node_modules/nuxt-og-image/dist/runtime/app/components/OgImage/OgImageScreenshot").default
  'NuxtPage': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/pages/runtime/page").default
  'NoScript': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").NoScript
  'Link': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Link
  'Base': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Base
  'Title': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Title
  'Meta': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Meta
  'Style': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Style
  'Head': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Head
  'Html': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Html
  'Body': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Body
  'NuxtIsland': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-island").default
  'LazyShowAuthError': LazyComponent<typeof import("../../app/components/ShowAuthError.vue").default>
  'LazyCommonGridShape': LazyComponent<typeof import("../../app/components/common/CommonGridShape.vue").default>
  'LazyCommonComponentCard': LazyComponent<typeof import("../../app/components/common/ComponentCard.vue").default>
  'LazyCommonComponentSubmitCard': LazyComponent<typeof import("../../app/components/common/ComponentSubmitCard.vue").default>
  'LazyCommonPageBreadcrumb': LazyComponent<typeof import("../../app/components/common/PageBreadcrumb.vue").default>
  'LazyCommonThemeToggler': LazyComponent<typeof import("../../app/components/common/ThemeToggler.vue").default>
  'LazyFormsFormElementsCheckboxInput': LazyComponent<typeof import("../../app/components/forms/FormElements/CheckboxInput.vue").default>
  'LazyFormsFormElementsDefaultInputs': LazyComponent<typeof import("../../app/components/forms/FormElements/DefaultInputs.vue").default>
  'LazyFormsFormElementsDropzone': LazyComponent<typeof import("../../app/components/forms/FormElements/Dropzone.vue").default>
  'LazyFormsFormElementsDropzoneImage copy': LazyComponent<typeof import("../../app/components/forms/FormElements/DropzoneImage copy.vue").default>
  'LazyFormsFormElementsDropzoneImage': LazyComponent<typeof import("../../app/components/forms/FormElements/DropzoneImage.vue").default>
  'LazyFormsFormElementsFileInput': LazyComponent<typeof import("../../app/components/forms/FormElements/FileInput.vue").default>
  'LazyFormsFormElementsInputGroup': LazyComponent<typeof import("../../app/components/forms/FormElements/InputGroup.vue").default>
  'LazyFormsFormElementsInputState': LazyComponent<typeof import("../../app/components/forms/FormElements/InputState.vue").default>
  'LazyFormsFormElementsSelectInput': LazyComponent<typeof import("../../app/components/forms/FormElements/SelectInput.vue").default>
  'LazyFormsFormElementsTextArea': LazyComponent<typeof import("../../app/components/forms/FormElements/TextArea.vue").default>
  'LazyLayoutAdminLayout': LazyComponent<typeof import("../../app/components/layout/AdminLayout.vue").default>
  'LazyLayoutAppHeader': LazyComponent<typeof import("../../app/components/layout/AppHeader.vue").default>
  'LazyLayoutAppSidebar': LazyComponent<typeof import("../../app/components/layout/AppSidebar.vue").default>
  'LazyLayoutBackdrop': LazyComponent<typeof import("../../app/components/layout/Backdrop.vue").default>
  'LazyLayoutFullScreenLayout': LazyComponent<typeof import("../../app/components/layout/FullScreenLayout.vue").default>
  'LazyLayoutSidebarProvider': LazyComponent<typeof import("../../app/components/layout/SidebarProvider.vue").default>
  'LazyLayoutSidebarWidget': LazyComponent<typeof import("../../app/components/layout/SidebarWidget.vue").default>
  'LazyLayoutThemeProvider': LazyComponent<typeof import("../../app/components/layout/ThemeProvider.vue").default>
  'LazyLayoutHeaderLogo': LazyComponent<typeof import("../../app/components/layout/header/HeaderLogo.vue").default>
  'LazyLayoutHeaderNotificationMenu copy': LazyComponent<typeof import("../../app/components/layout/header/NotificationMenu copy.vue").default>
  'LazyLayoutHeaderNotificationMenu': LazyComponent<typeof import("../../app/components/layout/header/NotificationMenu.vue").default>
  'LazyLayoutHeaderSearchBar': LazyComponent<typeof import("../../app/components/layout/header/SearchBar.vue").default>
  'LazyLayoutHeaderUserMenu': LazyComponent<typeof import("../../app/components/layout/header/UserMenu.vue").default>
  'LazyNuxtWelcome': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/welcome.vue").default>
  'LazyNuxtLayout': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-layout").default>
  'LazyNuxtErrorBoundary': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue").default>
  'LazyClientOnly': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/client-only").default>
  'LazyDevOnly': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/dev-only").default>
  'LazyServerPlaceholder': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/server-placeholder").default>
  'LazyNuxtLink': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-link").default>
  'LazyNuxtLoadingIndicator': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-loading-indicator").default>
  'LazyNuxtTime': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-time.vue").default>
  'LazyNuxtRouteAnnouncer': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-route-announcer").default>
  'LazyNuxtImg': LazyComponent<typeof import("../../node_modules/.pnpm/@nuxt+image@2.0.0_db0@0.3.4_ioredis@5.9.2_magicast@0.5.1/node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue").default>
  'LazyNuxtPicture': LazyComponent<typeof import("../../node_modules/.pnpm/@nuxt+image@2.0.0_db0@0.3.4_ioredis@5.9.2_magicast@0.5.1/node_modules/@nuxt/image/dist/runtime/components/NuxtPicture.vue").default>
  'LazyIcon': LazyComponent<typeof import("../../node_modules/.pnpm/@nuxt+icon@2.2.0_magicast@0.5.1_vite@7.3.1_@types+node@25.0.9_jiti@2.6.1_lightningcss@1_6da89c9b593b6e4c25ec361b88ecb6f2/node_modules/@nuxt/icon/dist/runtime/components/index").default>
  'LazyColorScheme': LazyComponent<typeof import("../../node_modules/.pnpm/@nuxtjs+color-mode@4.0.0_magicast@0.5.1/node_modules/@nuxtjs/color-mode/dist/runtime/component.vue").default>
  'LazyOgImage': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt-og-image@5.1.13_@unhead+vue@2.1.2_vue@3.5.27_typescript@5.9.3___magicast@0.5.1_uns_8d5afb97e113681a3783549c3b584ba2/node_modules/nuxt-og-image/dist/runtime/app/components/OgImage/OgImage").default>
  'LazyOgImageScreenshot': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt-og-image@5.1.13_@unhead+vue@2.1.2_vue@3.5.27_typescript@5.9.3___magicast@0.5.1_uns_8d5afb97e113681a3783549c3b584ba2/node_modules/nuxt-og-image/dist/runtime/app/components/OgImage/OgImageScreenshot").default>
  'LazyNuxtPage': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/pages/runtime/page").default>
  'LazyNoScript': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").NoScript>
  'LazyLink': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Link>
  'LazyBase': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Base>
  'LazyTitle': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Title>
  'LazyMeta': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Meta>
  'LazyStyle': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Style>
  'LazyHead': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Head>
  'LazyHtml': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Html>
  'LazyBody': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/head/runtime/components").Body>
  'LazyNuxtIsland': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@parcel+watcher@2.5.4_@types+node@25.0.9_@vue+compiler-sfc@3.5.27_cac@6.7.14_6a4f151f582de656f5dafd790cf6aa20/node_modules/nuxt/dist/app/components/nuxt-island").default>
}

declare module 'vue' {
  export interface GlobalComponents extends _GlobalComponents { }
}

export {}
